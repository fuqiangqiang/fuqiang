/* 百度地图API V2 模块
 * 此模块必须配套使用baidumap_offline_v2_20160822.js对
 * 获取模块的方法：
 * http://api0.map.bdimg.com/getmodules?v=2.0&mod=模块1,模块2
 * 模块名称就是文件名
 * www.xiaoguo123.com 整理
 */
 _jsload2&&_jsload2('markeranimation', 'Cc[1]={options:{duration:400},Bm:[{$b:0,translate:[0,-500],gc:"ease-in"},{$b:0.5,translate:[0,0],gc:"ease-out"},{$b:0.75,translate:[0,-20],gc:"ease-in"},{$b:1,translate:[0,0],gc:"ease-out"}],Tt:[{$b:0,translate:[375,-375],gc:"ease-in"},{$b:0.5,translate:[0,0],gc:"ease-out"},{$b:0.75,translate:[15,-15],gc:"ease-in"},{$b:1,translate:[0,0],gc:"ease-out"}]}; Cc[2]={options:{duration:700,loop:ub},Bm:[{$b:0,translate:[0,0],gc:"ease-out"},{$b:0.5,translate:[0,-20],gc:"ease-in"},{$b:1,translate:[0,0],gc:"ease-out"}],Tt:[{$b:0,translate:[0,0],gc:"ease-out"},{$b:0.5,translate:[15,-15],gc:"ease-in"},{$b:1,translate:[0,0],gc:"ease-out"}]};Cc[3]={options:{duration:200,GO:o},Bm:[{$b:0,translate:[0,0],gc:"ease-in"},{$b:1,translate:[0,-20],gc:"ease-out"}],Tt:[{$b:0,translate:[0,0],gc:"ease-in"},{$b:1,translate:[15,-15],gc:"ease-out"}]}; Cc[4]={options:{duration:500,GO:o},Bm:[{$b:0,translate:[0,-20],gc:"ease-in"},{$b:0.5,translate:[0,0],gc:"ease-out"},{$b:0.75,translate:[0,-10],gc:"ease-in"},{$b:1,translate:[0,-0.0],gc:"ease-out"}],Tt:[{$b:0,translate:[15,-15],gc:"ease-in"},{$b:0.5,translate:[0,0],gc:"ease-out"},{$b:0.75,translate:[8,-8],gc:"ease-in"},{$b:1,translate:[0,0],gc:"ease-out"}]}; ');
